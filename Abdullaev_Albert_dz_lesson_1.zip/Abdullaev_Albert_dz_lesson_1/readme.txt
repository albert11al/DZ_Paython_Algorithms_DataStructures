Из методички оставляем номера: 1, 5, 8. Доп задачи:
1. https://leetcode.com/problems/remove-duplicates-from-sorted-array/
2. https://leetcode.com/problems/move-zeroes/
3. Подумать как задачу по удалению элемента можно сделать без создания нового массива